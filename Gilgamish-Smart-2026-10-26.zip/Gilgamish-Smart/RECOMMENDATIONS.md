# Travel recommendations — 16 October 2026

The planner now calls authenticated `GET /api/recommendations?tripId=...` and displays up to three distinct flights and three hotels. Trip ownership is enforced before fetching providers. Fewer available offers are shown honestly; missing categories are never fabricated.

Ranking uses actual provider fields and deterministic rules, not language-model guesses. Currency-mismatched and invalid prices are excluded. Offers that can fit the total budget with the cheapest available companion offer, food for every traveler, transport, and other allowances rank first. Activity fees are excluded and the UI explains that selecting a different combination can cost more.

Flights then prioritize fewer stops when requested, shortest round-trip duration when requested, and price. Hotels prioritize closeness to the requested star category, then price. Missing star data ranks after known data. Guest reviews and location are not scored in this version; live hotel star ratings are currently unavailable in the adapter. Suggestions explain these criteria in Arabic and English.

The traveler selects a flight and hotel before invoking the existing itinerary generator, which receives those selections, interests, preferences and travel windows. Provider inventory is checked again during generation; expired offer IDs require refreshing. Live AI/provider credentials remain necessary for live operation. Mock mode remains explicitly labeled.

Validation: 22 backend tests, including recommendation ordering, budget allowances, missing data, ownership and selected-offer generation; production frontend build. Live providers, MySQL integration and interactive browser acceptance were not rerun for this change. Historical STATUS/VERIFICATION documents describe the earlier checkpoint; backend files now include recommendation changes.
