
const fs = require("fs");
const readline = require("readline");
const mysql = require("mysql2/promise");

const env = fs.readFileSync("backend/.env", "utf8");

for (const line of env.split(/\r?\n/)) {
  const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
  if (!match) continue;

  let value = match[2].trim();
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    value = value.slice(1, -1);
  }

  if (!Object.hasOwn(process.env, match[1])) {
    process.env[match[1]] = value;
  }
}

const DATASET =
  "D:/Gilgamish-Datasets/exports/gilgamish_places_master.jsonl";

async function main() {
  const db = await mysql.createConnection({
    host: process.env.DB_HOST || "127.0.0.1",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: "utf8mb4"
  });

  const input = readline.createInterface({
    input: fs.createReadStream(DATASET, { encoding: "utf8" }),
    crlfDelay: Infinity
  });

  let inserted = 0;
  let skipped = 0;

  const sql = `
    INSERT INTO tourist_places (
      overture_id, name, category, taxonomy_primary,
      latitude, longitude, country, target_city,
      administrative_area, boundary_level,
      inside_administrative_area, requires_geo_review,
      confidence, properties_json, location
    )
    VALUES (
      ?, ?, ?, ?,
      ?, ?, ?, ?,
      ?, ?,
      ?, ?,
      ?, ?, ST_SRID(POINT(?, ?), 4326)
    )
    ON DUPLICATE KEY UPDATE overture_id = overture_id
  `;

  try {
    await db.beginTransaction();

    for await (const line of input) {
      if (inserted + skipped >= 100) break;
      if (!line.trim()) continue;

      const p = JSON.parse(line);

      if (
        !Number.isFinite(p.latitude) ||
        !Number.isFinite(p.longitude) ||
        p.latitude < -90 || p.latitude > 90 ||
        p.longitude < -180 || p.longitude > 180
      ) {
        skipped++;
        continue;
      }

      const [result] = await db.execute(sql, [
        p.overture_id,
        p.name,
        p.category,
        p.taxonomy_primary,
        p.latitude,
        p.longitude,
        p.country,
        p.target_city,
        p.administrative_area,
        p.boundary_level,
        p.inside_administrative_area,
        p.requires_geo_review,
        p.confidence,
        p.properties_json,
        p.longitude,
        p.latitude
      ]);

      if (result.affectedRows === 1) inserted++;
      else skipped++;
    }

    await db.commit();

    const [rows] = await db.query(`
      SELECT id, name, target_city, latitude, longitude
      FROM tourist_places
      ORDER BY id DESC
      LIMIT 5
    `);

    console.log("TEST IMPORT SUCCESSFUL");
    console.log("Inserted:", inserted);
    console.log("Skipped:", skipped);
    console.table(rows);

  } catch (error) {
    await db.rollback();
    throw error;
  } finally {
    input.close();
    await db.end();
  }
}

main().catch(error => {
  console.error("IMPORT FAILED");
  console.error("Code:", error.code);
  console.error("Message:", error.message);
  process.exitCode = 1;
});
