import { loadConfig } from "../backend/src/config/env.js";

try {
  const config = loadConfig();
  const rows = Object.entries(config.providerModes).map(([service, provider]) => ({ service, provider,
    state: provider === "demo" ? "fixed demo city catalog; no API key" : provider === "mock" ? "fixture data" : provider === "rules" ? "local planning rules; no language model or key" : "configured; live request not yet verified" }));
  console.table(rows);
  const required = { destinations: ["AMADEUS_CLIENT_ID", "AMADEUS_CLIENT_SECRET"], flights: ["AMADEUS_CLIENT_ID", "AMADEUS_CLIENT_SECRET"], hotels: ["AMADEUS_CLIENT_ID", "AMADEUS_CLIENT_SECRET"] };
  for (const service of ["flights", "hotels"]) {
    const missing = required[service].filter((key) => !process.env[key]?.trim());
    console.log(`${service}: provisional Amadeus adapter; ${missing.length ? `missing ${missing.join(", ")}` : "credentials present (not verified)"}. Provider selection is still pending.`);
  }
  console.log("Chatbot: deferred. This command never prints credentials or creates a booking.");
} catch (error) { console.error(`Configuration check failed: ${error.message}`); process.exitCode = 1; }
