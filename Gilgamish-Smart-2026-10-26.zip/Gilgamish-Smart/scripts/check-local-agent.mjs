// Offline rule-based check. Writes no user accounts, calls no model and makes no bookings.
import { mkdir, writeFile } from "node:fs/promises";
import { loadConfig } from "../backend/src/config/env.js";
import { createRuleBasedPlanner } from "../backend/src/services/ruleBasedPlanner.js";
import { createMockServices } from "../backend/src/providers/mockServices.js";
import { createJourneyAgent } from "../backend/src/services/journeyAgent.js";
import { tripFixture } from "../backend/tests/support/fixture.js";
import { addDays } from "../backend/src/utils/dates.js";

loadConfig({ ...process.env, AI_PROVIDER: "rules" });
const fixtures = createMockServices();
const base = tripFixture({ language: "ar" });
const input = { ...base, endDate: addDays(base.startDate, 1), interests: ["history", "food"] };
const [flight] = await fixtures.travel.flights(input), [hotel] = await fixtures.travel.hotels(input);
const places = await fixtures.places.search(input);
const providers = { ...fixtures, plannerMode: "rules", aiMode: "rules", modes: { routes: "mock", ai: "rules" }, ai: createRuleBasedPlanner() };
const start = Date.now();
try {
  const result = await createJourneyAgent(providers).plan({ input, flight, hotel, places });
  const summary = { checkedAt: new Date().toISOString(), plannerEngine: "rules", languageModelCalls: 0, durationSeconds: (Date.now() - start) / 1000,
    data: "explicit development fixtures", chatbot: "deferred", report: result.report,
    dayCount: result.days.length, activityCount: result.days.reduce((count, day) => count + day.items.length, 0) };
  if (!summary.activityCount || summary.dayCount !== 2) throw new Error("No complete two-day plan with activities was produced.");
  await mkdir(new URL("../docs/verification/", import.meta.url), { recursive: true });
  await writeFile(new URL("../docs/verification/rules-agent.json", import.meta.url), JSON.stringify(summary, null, 2));
  console.log(JSON.stringify(summary, null, 2));
} catch (error) { console.error(`Rules agent check failed: ${error.code || "CHECK_FAILED"}: ${error.message}`); process.exitCode = 1; }
