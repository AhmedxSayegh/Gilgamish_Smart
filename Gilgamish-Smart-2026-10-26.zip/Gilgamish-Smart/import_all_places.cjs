
const fs = require("fs");
const mysql = require("mysql2/promise");

// Load environment variables
const envText = fs.readFileSync("backend/.env", "utf8");

for (const line of envText.split(/\r?\n/)) {
  const match = line.match(
    /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/
  );

  if (!match) continue;

  let value = match[2].trim();

  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    value = value.slice(1, -1);
  }

  if (!Object.hasOwn(process.env, match[1])) {
    process.env[match[1]] = value;
  }
}

const DATASET =
  "D:/Gilgamish-Datasets/exports/gilgamish_places_master.jsonl";

const BATCH_SIZE = 1000;
const EXPECTED_TOTAL = 1139343;

// Read JSONL using actual newline characters only.
// This avoids readline splitting on Unicode U+2028 / U+2029.
async function* readJsonl(path) {
  const stream = fs.createReadStream(path, {
    encoding: "utf8",
    highWaterMark: 1024 * 1024
  });

  let buffer = "";

  for await (const chunk of stream) {
    buffer += chunk;

    let index;

    while ((index = buffer.indexOf("\n")) !== -1) {
      const line = buffer.slice(0, index);
      buffer = buffer.slice(index + 1);

      if (line.trim()) {
        yield JSON.parse(line);
      }
    }
  }

  if (buffer.trim()) {
    yield JSON.parse(buffer);
  }
}

const columns = [
  "overture_id",
  "name",
  "category",
  "taxonomy_primary",
  "latitude",
  "longitude",
  "country",
  "target_city",
  "administrative_area",
  "boundary_level",
  "inside_administrative_area",
  "requires_geo_review",
  "confidence",
  "properties_json"
];

const sql = `
  INSERT IGNORE INTO tourist_places (
    ${columns.join(", ")}, location
  ) VALUES (
    ${columns.map(() => "?").join(", ")},
    ST_SRID(POINT(?, ?), 4326)
  )
`;

async function main() {
  if (!fs.existsSync(DATASET)) {
    throw new Error("Dataset file not found");
  }

  const db = await mysql.createConnection({
    host: process.env.DB_HOST || "127.0.0.1",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    charset: "utf8mb4",
    connectTimeout: 15000
  });

  let read = 0;
  let inserted = 0;
  let duplicates = 0;
  let invalid = 0;
  let batch = [];

  async function saveBatch() {
    if (batch.length === 0) return;

    await db.beginTransaction();

    let batchInserted = 0;
    let batchDuplicates = 0;

    try {
      for (const p of batch) {
        const values = [
          ...columns.map(key => p[key] ?? null),
          p.longitude,
          p.latitude
        ];

        const [result] = await db.execute(sql, values);

        if (result.affectedRows === 1) {
          batchInserted++;
        } else {
          batchDuplicates++;
        }
      }

      await db.commit();

      inserted += batchInserted;
      duplicates += batchDuplicates;

    } catch (error) {
      await db.rollback();
      throw error;
    }

    batch = [];

    console.log(
      `Read: ${read.toLocaleString()} / ${EXPECTED_TOTAL.toLocaleString()} | ` +
      `Inserted: ${inserted.toLocaleString()} | ` +
      `Existing/ignored: ${duplicates.toLocaleString()} | ` +
      `Invalid: ${invalid}`
    );
  }

  try {
    const [database] = await db.query(
      "SELECT DATABASE() AS name"
    );

    if (database[0].name !== "gilgamish") {
      throw new Error(
        "Unexpected database: " + database[0].name
      );
    }

    console.log("Connected to MySQL");
    console.log("Database:", database[0].name);
    console.log("Starting dataset import...\n");

    for await (const p of readJsonl(DATASET)) {
      read++;

      if (
        !p.overture_id ||
        !Number.isFinite(p.latitude) ||
        !Number.isFinite(p.longitude) ||
        p.latitude < -90 ||
        p.latitude > 90 ||
        p.longitude < -180 ||
        p.longitude > 180
      ) {
        invalid++;
        continue;
      }

      batch.push(p);

      if (batch.length >= BATCH_SIZE) {
        await saveBatch();
      }
    }

    await saveBatch();

    const [result] = await db.query(
      "SELECT COUNT(*) AS total FROM tourist_places"
    );

    console.log("\n==========================");
    console.log("IMPORT FINISHED");
    console.log("==========================");
    console.log("Source records:", read);
    console.log("Newly inserted:", inserted);
    console.log("Existing/ignored:", duplicates);
    console.log("Invalid coordinates/IDs:", invalid);
    console.log("Total in MySQL:", result[0].total);

    if (read !== EXPECTED_TOTAL) {
      console.warn(
        "WARNING: Source count differs from expected"
      );
    }

  } finally {
    await db.end();
  }
}

main().catch(error => {
  console.error(
    "IMPORT FAILED:",
    error.code || error.name
  );
  console.error(error.message);
  process.exitCode = 1;
});
