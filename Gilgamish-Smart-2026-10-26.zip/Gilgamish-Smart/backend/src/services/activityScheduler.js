import { isOpen, transferMinutes } from "./itineraryService.js";
import { minutes, clock } from "../utils/dates.js";
import { AppError } from "../utils/errors.js";

// Shared schedule helper: selections may come from application code or test fixtures.
export function scheduleActivities(selections, places, window, limit) {
  if (!Array.isArray(selections) || selections.length > limit)
    throw new AppError(422, "INVALID_SELECTION", "Choose no more than the requested number of activities.");
  const byId = new Map(places.map(place => [place.id, place]));
  const seen = new Set(), items = [];
  for (const selection of selections) {
    const place = byId.get(selection.placeId);
    if (!place || seen.has(selection.placeId) || typeof selection.reason !== "string" || !selection.reason.trim() || selection.reason.length > 500)
      throw new AppError(422, "INVALID_SELECTION", "Choose unique supplied place IDs and a short reason for each.");
    seen.add(selection.placeId);
    if (!window.canVisit || ["CLOSED_PERMANENTLY", "CLOSED_TEMPORARILY"].includes(place.businessStatus))
      throw new AppError(422, "CANNOT_SCHEDULE", "A selected activity is unavailable on this day.");
    const previous = items.at(-1);
    let start = previous
      ? minutes(previous.endTime) + transferMinutes(byId.get(previous.placeId), place)
      : minutes(window.startTime);
    const end = minutes(window.endTime);
    while (start + 60 <= end && !isOpen(place, window.date, start, start + 60)) start += 15;
    if (start + 60 > end)
      throw new AppError(422, "CANNOT_SCHEDULE", "Selected activities do not fit the available time or opening hours. Choose fewer or different places.");
    items.push({ placeId: place.id, startTime: clock(start), endTime: clock(start + 60), reason: selection.reason.trim() });
  }
  return { dayNumber: window.dayNumber, date: window.date, items };
}
