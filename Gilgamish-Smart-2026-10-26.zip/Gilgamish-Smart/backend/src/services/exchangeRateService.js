import { fetchJson, TtlCache } from "../providers/http.js";
import { AppError } from "../utils/errors.js";
import { amount, cents, currencies } from "../utils/currency.js";

export function createExchangeRateService(fetchImpl = fetch) {
  const cache = new TtlCache(20);
  return {
    async convert(offer, target) {
      if (offer.currency === target) return { ...offer };
      if (!/^[A-Z]{3}$/.test(offer.currency) || !currencies.includes(target))
        throw new AppError(422, "FX_CURRENCY_UNSUPPORTED", "Unsupported currency conversion.");
      let data = cache.get(offer.currency);
      if (!data) {
        data = await fetchJson(`https://open.er-api.com/v6/latest/${offer.currency}`, {}, { provider: "FX", fetchImpl });
        const updated = data.time_last_update_unix * 1000;
        if (data.result !== "success" || data.base_code !== offer.currency || !Number.isFinite(updated)
          || updated > Date.now() + 300000 || Date.now() - updated > 3 * 86400000)
          throw new AppError(502, "FX_INVALID_RESPONSE", "Current exchange rates are unavailable. Please retry.");
        cache.set(offer.currency, data, Math.max(1000, Math.min(3600000, updated + 3 * 86400000 - Date.now())));
      }
      const rate = data.rates?.[target];
      if (!Number.isFinite(rate) || rate <= 0)
        throw new AppError(502, "FX_RATE_UNAVAILABLE", "The requested exchange rate is unavailable.");
      const converted = Math.round(cents(offer.price) * rate);
      if (!Number.isSafeInteger(converted) || converted < 0)
        throw new AppError(502, "FX_INVALID_AMOUNT", "The converted price is invalid.");
      const price = amount(converted);
      cents(price);
      return { ...offer, price, currency: target, originalPrice: offer.price, originalCurrency: offer.currency,
        conversion: { rate, updatedAt: new Date(data.time_last_update_unix * 1000).toISOString(),
          source: "ExchangeRate-API", sourceUrl: "https://www.exchangerate-api.com", estimated: true } };
    },
  };
}
