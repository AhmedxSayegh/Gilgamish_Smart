import { fetchJson } from "../providers/http.js";
import { distanceKm } from "./rankingService.js";
import { demoCities, demoCityByCode } from "../../../shared/demoCities.mjs";
// Conservative planning area around Damascus, not an administrative boundary.
// Text matches alone can return businesses named Damascus in other countries.
const damascusArea = {
  low: { latitude: 33.46, longitude: 36.20 },
  high: { latitude: 33.57, longitude: 36.37 },
};
// Planning centers, not claimed administrative boundaries. No dataset lookup is used.
const centers = Object.fromEntries(demoCities.map((city) => [city.code, [city.latitude, city.longitude]]));
const interestQueries = {
  history: "historical landmarks", culture: "cultural landmarks", museums: "museums", cafes: "cafes",
  shopping: "shopping markets", nature: "parks", beaches: "beaches", photography: "scenic viewpoints",
  adventure: "outdoor recreation", family: "family attractions", nightlife: "nightlife venues",
  relaxation: "gardens", architecture: "historic architecture", local: "local markets", food: "restaurants",
};
function destinationScope(trip) {
  return trip.destinationCode === "DAM" || /^(damascus|دمشق)$/i.test(trip.destination?.trim() || "")
    ? { name: "Damascus, Syria", rectangle: damascusArea } : null;
}
function withinArea(place, area) {
  const { latitude, longitude } = place.location || {};
  return Number.isFinite(latitude) && Number.isFinite(longitude)
    && latitude >= area.low.latitude && latitude <= area.high.latitude
    && longitude >= area.low.longitude && longitude <= area.high.longitude;
}
const fields = [
  "id",
  "displayName",
  "types",
  "primaryType",
  "formattedAddress",
  "location",
  "rating",
  "userRatingCount",
  "regularOpeningHours",
  "priceLevel",
  "websiteUri",
  "googleMapsUri",
  "attributions",
  "businessStatus",
];
export function normalizePlace(p) {
  return {
    id: p.id,
    provider: "google",
    name: p.displayName?.text || null,
    types: p.types || [],
    type: p.primaryType || p.types?.[0] || "place",
    address: p.formattedAddress || null,
    latitude: p.location?.latitude ?? null,
    longitude: p.location?.longitude ?? null,
    rating: p.rating ?? null,
    reviewCount: p.userRatingCount ?? null,
    openingHours: p.regularOpeningHours?.periods ?? null,
    openingDescriptions: p.regularOpeningHours?.weekdayDescriptions || [],
    priceLevel: p.priceLevel || null,
    estimatedCost: null,
    currency: null,
    website: p.websiteUri || null,
    mapsUrl: p.googleMapsUri || null,
    attributions: p.attributions || [],
    observedAt: new Date().toISOString(),
    businessStatus: p.businessStatus || null,
  };
}
export function createGooglePlacesService(config, fetchImpl = fetch) {
  const request = (url, options, fieldMask) =>
    fetchJson(
      url,
      {
        ...options,
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": config.googleKey,
          "X-Goog-FieldMask": fieldMask,
        },
      },
      { provider: "GOOGLE_PLACES", fetchImpl },
    );
  return {
    async search(t) {
      const scope = destinationScope(t);
      const catalogCity = demoCityByCode(t.destinationCode);
      const center = centers[t.destinationCode];
      const anchor = center && { latitude: center[0], longitude: center[1] };
      const categories = [...new Set([
        "tourist attractions",
        "restaurants",
        ...t.interests.map((i) => interestQueries[i]).filter(Boolean),
      ])];
      const results = await Promise.all(
        categories
          .slice(0, 6)
          .map((category) =>
            request(
              "https://places.googleapis.com/v1/places:searchText",
              {
                method: "POST",
                body: JSON.stringify({
                  textQuery: `${category} in ${scope?.name || (catalogCity ? `${catalogCity.name}, ${catalogCity.country}` : t.destination)}`,
                  ...(scope ? { locationRestriction: { rectangle: scope.rectangle } } : {}),
                  ...(!scope && anchor ? { locationBias: { circle: { center: anchor, radius: 35000 } } } : {}),
                  languageCode: t.language,
                  pageSize: 15,
                }),
              },
              fields.map((x) => `places.${x}`).join(","),
            ),
          ),
      );
      return [
        ...new Map(
          results
            .flatMap((r) => r.places || [])
            .filter((p) => !["CLOSED_PERMANENTLY", "CLOSED_TEMPORARILY"].includes(p.businessStatus))
            .filter((p) => !scope || withinArea(p, scope.rectangle))
            .filter((p) => !anchor || (distanceKm(anchor, p.location) !== null && distanceKm(anchor, p.location) <= 50))
            .map((p) => [p.id, normalizePlace(p)]),
        ).values(),
      ];
    },
    async details(id, language = "en") {
      return normalizePlace(
        await request(
          `https://places.googleapis.com/v1/places/${encodeURIComponent(id)}?languageCode=${encodeURIComponent(language)}`,
          { method: "GET" },
          fields.join(","),
        ),
      );
    },
  };
}
