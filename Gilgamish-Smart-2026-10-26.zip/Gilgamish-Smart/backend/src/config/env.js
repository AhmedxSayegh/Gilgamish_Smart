import dotenv from "dotenv";
import { fileURLToPath } from "node:url";
dotenv.config({
  path: fileURLToPath(new URL("../../.env", import.meta.url)),
  quiet: true,
});
export function loadConfig(env = process.env) {
  const production = env.NODE_ENV === "production";
  const mock = env.USE_MOCK_SERVICES !== "false";
  const providerModes = {};
  for (const [service, live] of Object.entries({
    destinations: "amadeus", flights: "amadeus", hotels: "amadeus",
    places: "google", routes: "google", ai: "rules",
  })) {
    const name = `${service.toUpperCase()}_PROVIDER`;
    const selected = env[name] || (service === "destinations" ? "demo" : service === "ai" ? "rules" : service === "routes" ? "mock" : (mock ? "mock" : live));
    const allowed = service === "destinations" ? ["demo", "mock", live] : service === "ai" ? ["mock", "rules"] : ["mock", live];
    if (!allowed.includes(selected))
      throw new Error(`${name} must be one of: ${allowed.join(", ")}.`);
    providerModes[service] = selected;
  }
  if (production && !env.CLIENT_ORIGIN?.startsWith("https://"))
    throw new Error("Production requires an HTTPS CLIENT_ORIGIN.");
  const config = {
    production,
    mock,
    providerModes,
    aiProvider: providerModes.ai,
    googleRoutesKey: env.GOOGLE_ROUTES_API_KEY || env.GOOGLE_PLACES_API_KEY,
    port: Number(env.PORT || 4000),
    clientOrigin: env.CLIENT_ORIGIN || "http://localhost:5173",
    sessionDays: Number(env.SESSION_DAYS || 7),
    trustProxy: env.TRUST_PROXY === "true",
    db: {
      host: env.DB_HOST || "127.0.0.1",
      port: Number(env.DB_PORT || 3306),
      user: env.DB_USER || "gilgamish",
      password: env.DB_PASSWORD,
      database: env.DB_NAME || "gilgamish",
      ...(env.DB_SOCKET ? { socketPath: env.DB_SOCKET } : {}),
      ...(env.DB_SSL === "true" ? { ssl: { rejectUnauthorized: true } } : {}),
    },
    amadeusBase:
      env.AMADEUS_ENV === "production"
        ? "https://api.amadeus.com"
        : "https://test.api.amadeus.com",
    amadeusId: env.AMADEUS_CLIENT_ID,
    amadeusSecret: env.AMADEUS_CLIENT_SECRET,
    googleKey: env.GOOGLE_PLACES_API_KEY,
  };
  const required = {};
  if (providerModes.routes === "google") required.GOOGLE_ROUTES_API_KEY = config.googleRoutesKey;
  if ([providerModes.destinations, providerModes.flights, providerModes.hotels].includes("amadeus")) {
    required.AMADEUS_CLIENT_ID = config.amadeusId;
    required.AMADEUS_CLIENT_SECRET = config.amadeusSecret;
  }
  if (providerModes.places === "google") required.GOOGLE_PLACES_API_KEY = config.googleKey;
  for (const [key, value] of Object.entries(required)) {
    if (!value?.trim()) throw new Error(`${key} is required by the selected provider.`);
  }
  return config;
}
