import { createRuleBasedPlanner } from "../services/ruleBasedPlanner.js";
import { createGoogleRoutesService, createMockRoutesService } from "../services/googleRoutesService.js";
import { createMockServices } from "./mockServices.js";
import { createAmadeusService } from "../services/amadeusService.js";
import { createGooglePlacesService } from "../services/googlePlacesService.js";
export function createProviders(config) {
  const fixtures = createMockServices();
  const modes = config.providerModes || Object.fromEntries(
    ["destinations", "flights", "hotels", "places", "ai"].map((key) => [key, key === "ai" ? "rules" : config.mock ? "mock" : "live"]),
  );
  const amadeus = createAmadeusService(config);
  const values = Object.entries(modes).filter(([key]) => !["ai", "destinations"].includes(key)).map(([, value]) => value);
  return {
    mode: values.every((mode) => mode === "mock") ? "mock"
      : values.every((mode) => mode !== "mock") ? "live" : "mixed",
    modes,
    aiMode: modes.ai,
    plannerMode: modes.ai,
    routes: modes.routes === "google" ? createGoogleRoutesService(config) : createMockRoutesService(),
    travel: Object.fromEntries(["destinations", "flights", "hotels"].map((key) => [
      key, modes[key] === "mock" || (key === "destinations" && modes[key] === "demo") ? fixtures.travel[key] : amadeus[key],
    ])),
    places: modes.places === "mock" ? fixtures.places : createGooglePlacesService(config),
    ai: modes.ai === "mock" ? fixtures.ai : createRuleBasedPlanner(),
  };
}
