import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../src/config/env.js';
import { createProviders } from '../src/providers/index.js';

test('Google places, routes and rule-based planning coexist with independent mock flight/hotel providers', async () => {
  const config = loadConfig({ PLACES_PROVIDER: 'google', GOOGLE_PLACES_API_KEY: 'test', AI_PROVIDER: 'rules' });
  const providers = createProviders(config);
  assert.deepEqual(providers.modes, { destinations: 'demo', flights: 'mock', hotels: 'mock', places: 'google', routes: 'mock', ai: 'rules' });
  assert.equal(providers.mode, 'mixed');
  assert.equal(providers.aiMode, 'rules');
  const route = await providers.routes.compute({ origin: { latitude: 41, longitude: 29 }, destination: { latitude: 41.01, longitude: 29.01 } });
  assert.equal(route.isMock, true);
  assert.throws(() => loadConfig({ ROUTES_PROVIDER: 'google' }), /GOOGLE_ROUTES_API_KEY/);
  assert.throws(() => loadConfig({ ROUTES_PROVIDER: 'invalid' }), /ROUTES_PROVIDER/);
  const liveRoutes = loadConfig({ ROUTES_PROVIDER: 'google', GOOGLE_ROUTES_API_KEY: 'route-only' });
  assert.equal(liveRoutes.providerModes.places, 'mock');
  assert.equal(liveRoutes.googleRoutesKey, 'route-only');
  assert.equal(loadConfig({ ROUTES_PROVIDER: 'google', GOOGLE_PLACES_API_KEY: 'shared' }).googleRoutesKey, 'shared');
});
