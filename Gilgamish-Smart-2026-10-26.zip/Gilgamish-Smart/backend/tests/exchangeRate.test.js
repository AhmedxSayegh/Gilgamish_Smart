import test from "node:test";
import assert from "node:assert/strict";
import { createExchangeRateService } from "../src/services/exchangeRateService.js";
const snapshot = (patch = {}) => ({ result: "success", base_code: "GBP", time_last_update_unix: Math.floor(Date.now()/1000), rates: { USD: 1.25, SAR: 4.75, EUR: 1.15, AED: 4.6, TRY: 55 }, ...patch });
const response = (data, status=200) => new Response(JSON.stringify(data), {status});
test("FX converts all supported trip currencies with provenance, cached rates and intact original prices", async () => {
  let calls=0;
  const fx=createExchangeRateService(async (url, options) => { calls++; assert.equal(options.headers, undefined); return response(snapshot()); });
  const offer={price:'100.00',currency:'GBP'};
  for (const [currency,expected] of Object.entries({USD:'125.00',SAR:'475.00',EUR:'115.00',AED:'460.00',TRY:'5500.00'})) {
    const result=await fx.convert(offer,currency);
    assert.equal(result.price,expected); assert.equal(result.originalPrice,'100.00'); assert.equal(result.originalCurrency,'GBP');
    assert.equal(result.conversion.source,'ExchangeRate-API');
  }
  assert.equal(calls,1); assert.equal(offer.currency,'GBP'); assert.equal(offer.price,'100.00');
  assert.deepEqual(await fx.convert(offer,'GBP'),offer); assert.equal(calls,1);
});
test("FX refuses failed, stale, missing, negative and invalid rates instead of guessing", async () => {
  const offer={price:'10.00',currency:'GBP'};
  for(const data of [snapshot({result:'error'}),snapshot({base_code:'USD'}),snapshot({time_last_update_unix:1}),snapshot({rates:{}}),snapshot({rates:{USD:-1}}),snapshot({rates:{USD:'1.25'}})]) {
    const fx=createExchangeRateService(async()=>response(data));
    await assert.rejects(()=>fx.convert(offer,'USD'));
  }
  const failed=createExchangeRateService(async()=>response({},503));
  await assert.rejects(()=>failed.convert(offer,'USD'), {code:'FX_UNAVAILABLE'});
});
