import test from "node:test";
import assert from "node:assert/strict";
import { demoCities, demoCityByCode, searchDemoCities } from "../../shared/demoCities.mjs";
import { cities as frontendCities } from "../../frontend/src/lib/assets.js";
import { createProviders } from "../src/providers/index.js";
import { loadConfig } from "../src/config/env.js";
import { createMockServices } from "../src/providers/mockServices.js";
import { createAmadeusService } from "../src/services/amadeusService.js";
import { createGooglePlacesService } from "../src/services/googlePlacesService.js";
import { createRuleBasedPlanner } from "../src/services/ruleBasedPlanner.js";
import { validateItinerary } from "../src/services/itineraryService.js";
import { tripFixture } from "./support/fixture.js";
const response = (data) => new Response(JSON.stringify(data));

test("the demo catalog and frontend contain exactly the ten requested cities", () => {
  const expected = ["DAM", "IST", "MED", "QCA", "JED", "RUH", "AMM", "DXB", "CAI", "PAR"];
  assert.deepEqual(demoCities.map((c) => c.code), expected);
  assert.deepEqual(frontendCities.map((c) => c.code), expected);
  assert.equal(new Set(demoCities.map((c) => c.code)).size, 10);
  assert.deepEqual(searchDemoCities("London"), []);
  assert.ok(frontendCities.every((c) => c.name && c.ar && c.image && c.countryAr));
});

test("every demo city is searchable in Arabic/English; aliases and Arabic spelling variants work", async () => {
  const p = createProviders(loadConfig({}));
  assert.equal(p.modes.destinations, "demo");
  for (const city of demoCities) {
    assert.ok((await p.travel.destinations(city.name)).some((c) => c.code === city.code));
    assert.ok((await p.travel.destinations(city.nameAr)).some((c) => c.code === city.code));
  }
  for (const [query, code] of [["اسطنبول", "IST"], ["المدينه المنوره", "MED"], ["مكه", "QCA"], ["عمان", "AMM"], ["Medina", "MED"], ["Mecca", "QCA"]]) {
    assert.ok(searchDemoCities(query).some((c) => c.code === code));
  }
});

test("all ten cities support rule-based demo planning with fixture travel offers", async () => {
  const fixtures = createMockServices(), planner = createRuleBasedPlanner();
  for (const city of demoCities) {
    const input = tripFixture({ origin: city.code === "DAM" ? "Istanbul" : "Damascus", originCode: city.code === "DAM" ? "IST" : "DAM", destination: city.name, destinationCode: city.code });
    const c = { input, flight: (await fixtures.travel.flights(input))[0], hotel: (await fixtures.travel.hotels(input))[0], places: await fixtures.places.search(input) };
    const days = validateItinerary(await planner.generate(c), c);
    assert.ok(days.some((d) => d.items.length), city.name);
  }
});

test("Makkah stays a separate place/hotel destination while flights use Jeddah", async () => {
  const input = tripFixture({ origin: "Damascus", originCode: "DAM", destination: "Makkah", destinationCode: "QCA" });
  const paths = [];
  const service = createAmadeusService({ amadeusBase: "https://test.api.amadeus.com" }, async (url) => {
    if (String(url).endsWith("/token")) return response({ access_token: "test", expires_in: 3600 });
    const parsed = new URL(url); paths.push(parsed);
    if (parsed.pathname.endsWith("by-geocode")) return response({ data: [] });
    return response({ data: [] });
  });
  await service.flights(input); await service.hotels(input);
  assert.equal(paths[0].searchParams.get("destinationLocationCode"), "JED");
  assert.equal(paths[1].pathname, "/v1/reference-data/locations/hotels/by-geocode");
  assert.equal(Number(paths[1].searchParams.get("longitude")), demoCityByCode("QCA").longitude);
  const fixtures = createMockServices();
  assert.equal((await fixtures.travel.flights(input))[0].destination, "JED");
  await assert.rejects(() => fixtures.travel.flights(tripFixture({ destination: "Makkah", destinationCode: "QCA", originCode: "JED" })), { code: "GROUND_TRANSFER_REQUIRED" });
  await assert.rejects(() => service.flights(tripFixture({ destination: "Makkah", destinationCode: "QCA", originCode: "JED" })), { code: "GROUND_TRANSFER_REQUIRED" });
});

test("Google searches disambiguate demo city/country and use the destination center, not the airport gateway", async () => {
  for (const code of ["MED", "QCA", "CAI", "AMM"]) {
    const city = demoCityByCode(code), bodies = [];
    const service = createGooglePlacesService({}, async (_, options) => { bodies.push(JSON.parse(options.body)); return response({ places: [] }); });
    await service.search(tripFixture({ destination: city.name, destinationCode: city.code }));
    assert.ok(bodies.every((b) => b.textQuery.endsWith(`${city.name}, ${city.country}`)));
    assert.ok(bodies.every((b) => b.locationBias.circle.center.longitude === city.longitude));
  }
});
