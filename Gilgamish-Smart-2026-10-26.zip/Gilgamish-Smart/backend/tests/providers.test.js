import test from "node:test";
import assert from "node:assert/strict";
import { createAmadeusService } from "../src/services/amadeusService.js";
import { createGooglePlacesService } from "../src/services/googlePlacesService.js";
import { loadConfig } from "../src/config/env.js";
import { tripFixture } from "./support/fixture.js";
import { createProviders } from "../src/providers/index.js";
const response = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });

test("each provider requires only its own credentials and rejects invalid selections", () => {
  const env = {
    USE_MOCK_SERVICES: "true", PLACES_PROVIDER: "google", GOOGLE_PLACES_API_KEY: "test",
  };
  const config = loadConfig(env);
  assert.equal(config.providerModes.places, "google");
  assert.equal(config.providerModes.ai, "rules");
  assert.throws(() => loadConfig({ ...env, FLIGHTS_PROVIDER: "amadeus" }), /AMADEUS_CLIENT_ID/);
  assert.throws(() => loadConfig({ ...env, HOTELS_PROVIDER: "amadeus" }), /AMADEUS_CLIENT_ID/);
  assert.throws(() => loadConfig({ ...env, AI_PROVIDER: "external" }), /AI_PROVIDER/);
  assert.throws(() => loadConfig({ ...env, PLACES_PROVIDER: "typo" }), /PLACES_PROVIDER/);
  assert.doesNotThrow(() => loadConfig({ USE_MOCK_SERVICES: "true", AI_PROVIDER: "rules" }));
});

test("Google Places can run alongside fixture travel without silently falling back", async () => {
  const originalFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => { calls++; return response({ places: [{ id: "real-place", displayName: { text: "Museum" }, location: { latitude: 41.01, longitude: 28.98 } }] }); };
  try {
    const providers = createProviders(loadConfig({ USE_MOCK_SERVICES: "true", PLACES_PROVIDER: "google", GOOGLE_PLACES_API_KEY: "test" }));
    assert.equal(providers.mode, "mixed");
    const input = tripFixture();
    assert.equal((await providers.travel.flights(input))[0].provider, "mock");
    assert.equal((await providers.travel.hotels(input))[0].provider, "mock");
    assert.equal((await providers.places.search(input))[0].provider, "google");
    assert.ok(calls > 0);
  } finally { globalThis.fetch = originalFetch; }
  globalThis.fetch = async () => response({}, 403);
  try {
    const providers = createProviders(loadConfig({ USE_MOCK_SERVICES: "true", PLACES_PROVIDER: "google", GOOGLE_PLACES_API_KEY: "test" }));
    await assert.rejects(() => providers.places.search(tripFixture()), { code: "GOOGLE_PLACES_UNAVAILABLE" });
  } finally { globalThis.fetch = originalFetch; }
});
test("live mode fails fast without credentials and never substitutes fixtures", () =>
  assert.throws(
    () => loadConfig({ USE_MOCK_SERVICES: "false" }),
    /AMADEUS_CLIENT_ID/,
  ));
test("Amadeus caches tokens, sends round trip parameters, and normalizes both legs", async () => {
  let tokens = 0;
  const urls = [];
  const input = tripFixture();
  const fetchImpl = async (url, options) => {
    if (String(url).endsWith("/token")) {
      tokens++;
      assert.equal(options.method, "POST");
      return response({ access_token: "test-token", expires_in: 1800 });
    }
    urls.push(new URL(url));
    assert.equal(options.headers.Authorization, "Bearer test-token");
    return response({
      data: [
        {
          id: "F1",
          price: { grandTotal: "123.45", currency: "SAR" },
          itineraries: [
            {
              duration: "PT4H",
              segments: [
                {
                  carrierCode: "XX",
                  departure: {
                    iataCode: "JED",
                    at: `${input.startDate}T08:00:00`,
                  },
                  arrival: {
                    iataCode: "IST",
                    at: `${input.startDate}T12:00:00`,
                  },
                },
              ],
            },
            {
              duration: "PT4H",
              segments: [
                {
                  departure: {
                    iataCode: "IST",
                    at: `${input.endDate}T18:00:00`,
                  },
                  arrival: { iataCode: "JED", at: `${input.endDate}T22:00:00` },
                },
              ],
            },
          ],
        },
      ],
      dictionaries: { carriers: { XX: "Example" } },
    });
  };
  const api = createAmadeusService(
    {
      amadeusBase: "https://test.api.amadeus.com",
      amadeusId: "id",
      amadeusSecret: "secret",
    },
    fetchImpl,
  );
  const results = await Promise.all([
    api.flights(input),
    api.flights({ ...input, adults: 1 }),
  ]);
  assert.equal(tokens, 1);
  assert.equal(urls[0].searchParams.get("returnDate"), input.endDate);
  assert.equal(results[0][0].price, "123.45");
  assert.equal(results[0][0].returnDepartureTime, `${input.endDate}T18:00:00`);
  assert.equal(results[0][0].priceScope, "all_travelers_round_trip");
});
test("Amadeus exposes rate limits and unsupported child hotel occupancy", async () => {
  const api = createAmadeusService(
    {
      amadeusBase: "https://test.api.amadeus.com",
      amadeusId: "id",
      amadeusSecret: "secret",
    },
    async () => response({}, 429),
  );
  await assert.rejects(() => api.flights(tripFixture()), {
    code: "AMADEUS_UNAVAILABLE",
    status: 503,
  });
  await assert.rejects(() => api.hotels(tripFixture({ children: 1 })), {
    code: "HOTEL_CHILD_OCCUPANCY_UNSUPPORTED",
  });
});
test("Google Places requests explicit fields and leaves missing fees unknown", async () => {
  const api = createGooglePlacesService(
    { googleKey: "secret" },
    async (url, options) => {
      assert.ok(options.headers["X-Goog-FieldMask"].includes("places.id"));
      assert.ok(!options.headers["X-Goog-FieldMask"].includes("*"));
      assert.equal(JSON.parse(options.body).languageCode, "en");
      return response({
        places: [
          {
            id: "place-1",
            displayName: { text: "Museum" },
            types: ["museum"],
            rating: 4.6,
            location: { latitude: 41, longitude: 29 },
          },
        ],
      });
    },
  );
  const [place] = await api.search(tripFixture());
  assert.equal(place.name, "Museum");
  assert.equal(place.estimatedCost, null);
  assert.equal(place.openingHours, null);
  assert.equal(place.provider, "google");
});
