# Gilgamish Smart — working checkpoint

Updated: 2026-10-26, Asia/Damascus. Read this file before resuming project work.

## Current active decision — 26 October 2026

The user explicitly approved removing language models from trip planning. The active engine is `AI_PROVIDER=rules`: deterministic interest/proximity/budget selection, opening-aware scheduling and bounded agent repair. Qwen/Ollama and external-language-model planning services were removed from the application. The desktop launcher does not start or require Ollama. No new trained model or Colab dependency was introduced. See `docs/RULE-BASED-PLANNING.md`.

Google Places and Google Routes remain live. Flights/hotels remain mock until vendors and credentials are supplied. Destination lookup now defaults to `demo`: the user's fixed ten-city catalog (Damascus, Istanbul, Madinah, Makkah, Jeddah, Riyadh, Amman, Dubai, Cairo, Paris), shared with the frontend and searchable in Arabic/English. No global city-lookup vendor is required for this demo. Makkah has a distinct place/hotel center and uses Jeddah as its flight gateway; ground-transfer time/cost are unquoted and warned. Jeddah–Makkah flights are rejected as a ground-transfer pair. See `docs/DEMO-CITIES.md`. Informational chatbot/RAG remains absent and deferred. The `aiMode` health field is retained for compatibility, now `rules`; `plannerEngine=rules` describes the implementation.

Verified on 26 October: 59 backend tests, frontend build, and MySQL integration passed. The dedicated MySQL integration now uses the real rule-based planner rather than the fixture generator. Real Places + Routes + rules + SQL acceptance produced six activities across two days in 1.699 seconds, with six unknown fees explicitly retained. HTTP instrumentation allowed only places.googleapis.com (3 requests) and routes.googleapis.com (2 requests); no language-model calls. Evidence: `docs/verification/rules-live-journey.json`. The test account was deleted. START-GILGAMISH.cmd was exercised successfully without starting/checking Ollama; the running site's health confirms plannerEngine=rules. The timing is one acceptance example, not a general performance guarantee.

Demo-city update verified on 26 October: all 64 backend tests and the frontend build passed. The real Google Places service returned 30 usable, geographically filtered candidates for each of the ten cities, using 20 requests total; counts only are saved in `docs/verification/demo-cities.json`. This checks basic attraction/restaurant search, not full itineraries or travel inventory for all cities. The local backend was restarted; health through http://localhost:5180 confirms database/status=ok, destinations=demo, places/routes=google, flights/hotels=mock, plannerEngine=rules and chatbot=deferred. The prior MySQL/full-journey acceptance above remains a separate earlier check.

## User decisions

- Finish the backend and the trip-planning AI agent first, following the supplied project diagram WITHOUT the chatbot branches.
- Treat the chatbot as absent and deferred. Its agreed purpose and unresolved options are recorded in `docs/CHATBOT-DEFERRED.md`. Do not build chat routes, chat UI, RAG, or conversation-driven trip generation in the current work.
- Duffel was removed at the user's request. Do not restore it.
- Flight and hotel provider names have NOT been selected (confirmed by the user). Prepare independent provider contracts using the existing Amadeus adapter as a provisional implementation; do not claim an unknown provider will work merely by adding any API key.
- User will supply flight/hotel credentials locally later. Keep fixtures clearly labeled while credentials are unavailable. No payments, reservations, or bookings are authorized by this work.
- Google Places supplies the runtime place candidates. The Colab notebook is not an application dependency. Current ranking is explainable application logic, not a trained recommender.
- The trip-planning AI agent is separate from the deferred informational chatbot.

## Historical starting state — 25 October 2026

- Express/React/MySQL, account sessions, ownership, trip/plan versioning, editing, budgets and print views exist.
- Google Places is configured; flight/hotel/destination/routes and AI providers were configured as mock.
- Local Ollama inference code and an installed model exist from prior work; availability must be checked before claiming it is running.
- Historical `AGENT-WORKFLOW.md` referred to `journeyAgent.js`, which was absent. That document was not evidence of an integrated working agent.
- Independent provider selection exists. No live flight/hotel verification has been performed.
- Currency conversion helper exists but has no active flight-provider consumer after Duffel removal.

## Current scope

1. Bounded planning agent: provider tools, preference-aware candidate ranking, offer selection, rule-based generation, validation, evaluation, bounded revision, report, persistence.
2. Google candidate search by interests and geography; deterministic diversity and duplicate handling.
3. Preserve selected flight/hotel IDs; never invent provider inventory or known fees.
4. Keep unknown fees and estimated transfers explicit; integrate route checks when enabled.
5. Provider readiness/configuration guide and checks, tests, full plan persistence verification.
6. Update this checkpoint with actual outcomes and unverified boundaries when work completes.

See `docs/BACKEND-AGENT-PLAN.md` for the implementation sequence and verification record.

## Historical outcome — 25 October 2026 (superseded by rules above)

- Bounded journeyAgent.js is implemented and integrated in full/day generation. It validates model drafts, checks real route legs when enabled, evaluates known costs/interest coverage/repeats/empty days, revises at most three times, and persists the best valid full-plan report. Upstream outages fail instead of substituting data.
- Explicit flight/hotel choices survive regeneration unless the traveler requests cheaper alternatives or new choices; expired IDs require refresh.
- Google search uses interests with at most six queries, known-city planning scopes, closure filtering; ranking deduplicates and preserves interest/type variety.
- Local AI and Google Routes are now enabled after successful real checks. Health: aiMode=ollama, planningMode=agent, routes=google, places=google, chatbot=deferred. Flight/hotel/destination modes remain mock pending vendor selection.
- 55 backend tests, frontend build and dedicated MySQL integration passed. Real Google Places + Google Routes + local model + SQL acceptance produced six activities across two days in 65.238 seconds; test account was removed. See docs/verification/live-journey.json.
- Start locally with START-GILGAMISH.cmd. It uses the existing local-ai-runtime/start-local-ai.ps1 and MySQL service MySQLAyham2003. Site: http://localhost:5180. The PC must be on for local AI.
- Outstanding: vendor choice/credentials and final live flight/hotel testing, broader quality/long-trip load evaluation, deployment. Chatbot is intentionally absent; read docs/CHATBOT-DEFERRED.md when resuming it.
